# P507-FrontEnd-Layihe

Aşağıda linkdə verilən səhifələri yığmalı:



https://fiorello.mikado-themes.com

https://fiorello.mikado-themes.com/product/orange-amaryllis/

https://fiorello.mikado-themes.com/elements/accordions/

https://fiorello.mikado-themes.com/elements/tabs/

https://fiorello.mikado-themes.com/elements/shop-list/

https://fiorello.mikado-themes.com/elements/progress-bar/



Sabahdan bashlayaraq her gun commit etmeyi unutmayin !!!

#UĞURLAR
